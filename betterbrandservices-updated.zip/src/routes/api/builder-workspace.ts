import { randomBytes } from 'node:crypto'
import { createFileRoute } from '@tanstack/react-router'
import { getDb, requireSessionUser } from '../../lib/session'
import { generateWebsite, reviseWebsite, BbsAiConfigError, BbsAiGenerationError } from '../../lib/bbs-ai-engine'
import { checkDomain, buildDnsInstructions } from '../../lib/domain-verification'
import { publishProject, attachDomain, PublishConfigError, PublishError } from '../../lib/site-publisher'

/**
 * BBS AI is the ONLY generation engine for the workspace (see
 * src/lib/bbs-ai-engine.ts — it calls the Anthropic API directly).
 * There is intentionally no provider selection, model dropdown, or
 * third-party engine (OpenAI / Codex / Gemini / Lovable) anywhere in
 * this backend. Every project is built and revised by BBS AI.
 *
 * Every action below requires a valid session and every query is scoped
 * to the authenticated user's own rows.
 */

type Action =
  | 'create-project'
  | 'add-message'
  | 'add-domain'
  | 'verify-domain'
  | 'publish'

const json = (body: unknown, status = 200) => Response.json(body, { status })

const errorResponse = (error: unknown) => {
  if (error instanceof BbsAiConfigError || error instanceof PublishConfigError) {
    return json({ error: error.message }, 503)
  }
  if (error instanceof BbsAiGenerationError || error instanceof PublishError) {
    return json({ error: error.message }, 502)
  }
  const status = (error as { status?: number })?.status
  if (status) {
    return json({ error: (error as Error).message }, status)
  }
  console.error('[BBS WORKSPACE ERROR]', error)
  return json({ error: (error as Error)?.message || 'The BBS workspace request failed.' }, 500)
}

const ensureTables = async () => {
  const sql = getDb()

  await sql`
    CREATE TABLE IF NOT EXISTS bbs_projects (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      name TEXT NOT NULL,
      initial_prompt TEXT NOT NULL,
      provider TEXT NOT NULL DEFAULT 'bbs-ai',
      status TEXT NOT NULL DEFAULT 'draft',
      published_url TEXT,
      custom_domain TEXT,
      platform_site_id TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `
  // Backfill for databases created before user_id / platform_site_id existed.
  await sql`ALTER TABLE bbs_projects ADD COLUMN IF NOT EXISTS user_id TEXT`
  await sql`ALTER TABLE bbs_projects ADD COLUMN IF NOT EXISTS platform_site_id TEXT`

  await sql`
    CREATE TABLE IF NOT EXISTS bbs_builder_messages (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'complete',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `
  await sql`ALTER TABLE bbs_builder_messages ADD COLUMN IF NOT EXISTS user_id TEXT`

  await sql`
    CREATE TABLE IF NOT EXISTS bbs_domains (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      project_id TEXT,
      hostname TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'needs_configuration',
      record_type TEXT,
      expected_target TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `
  await sql`ALTER TABLE bbs_domains ADD COLUMN IF NOT EXISTS user_id TEXT`
  await sql`ALTER TABLE bbs_domains ADD COLUMN IF NOT EXISTS record_type TEXT`
  await sql`ALTER TABLE bbs_domains ADD COLUMN IF NOT EXISTS expected_target TEXT`

  await sql`
    CREATE TABLE IF NOT EXISTS bbs_deployments (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      project_id TEXT NOT NULL,
      project_name TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'building',
      published_url TEXT,
      is_latest BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `
  await sql`ALTER TABLE bbs_deployments ADD COLUMN IF NOT EXISTS user_id TEXT`
}

const projectColumns = `id, name, initial_prompt, provider, status, published_url, custom_domain, platform_site_id, created_at, updated_at`
const messageColumns = `id, project_id, role, content, status, created_at`
const domainColumns = `id, project_id, hostname, status, record_type, expected_target, created_at, updated_at`
const deploymentColumns = `id, project_id, project_name, status, published_url, is_latest, created_at`

const getWorkspace = async (userId: string) => {
  const sql = getDb()

  const [projects, domains, deployments, messages] = await Promise.all([
    sql`SELECT ${sql.unsafe(projectColumns)} FROM bbs_projects WHERE user_id = ${userId} ORDER BY updated_at DESC`,
    sql`SELECT ${sql.unsafe(domainColumns)} FROM bbs_domains WHERE user_id = ${userId} ORDER BY created_at DESC`,
    sql`SELECT ${sql.unsafe(deploymentColumns)} FROM bbs_deployments WHERE user_id = ${userId} ORDER BY created_at DESC`,
    sql`SELECT ${sql.unsafe(messageColumns)} FROM bbs_builder_messages WHERE user_id = ${userId} ORDER BY created_at ASC`,
  ])

  return { projects, domains, deployments, messages }
}

const getOwnedProject = async (userId: string, projectId: string) => {
  const sql = getDb()
  const [project] = await sql`
    SELECT ${sql.unsafe(projectColumns)} FROM bbs_projects
    WHERE id = ${projectId} AND user_id = ${userId}
  `
  if (!project) {
    throw Object.assign(new Error('Project not found.'), { status: 404 })
  }
  return project
}

const createProject = async (userId: string, { prompt, name }: { prompt: string; name: string }) => {
  const sql = getDb()

  const projectId = randomBytes(16).toString('hex')
  const userMessageId = randomBytes(16).toString('hex')
  const generatedMessageId = randomBytes(16).toString('hex')

  await sql`
    INSERT INTO bbs_projects (id, user_id, name, initial_prompt, provider, status)
    VALUES (${projectId}, ${userId}, ${name}, ${prompt}, 'bbs-ai', 'building')
  `
  await sql`
    INSERT INTO bbs_builder_messages (id, project_id, user_id, role, content, status)
    VALUES (${userMessageId}, ${projectId}, ${userId}, 'user', ${prompt}, 'complete')
  `

  try {
    const html = await generateWebsite(prompt)

    await sql`
      INSERT INTO bbs_builder_messages (id, project_id, user_id, role, content, status)
      VALUES (${generatedMessageId}, ${projectId}, ${userId}, 'assistant', ${html}, 'complete')
    `
    await sql`UPDATE bbs_projects SET status = 'draft', updated_at = NOW() WHERE id = ${projectId}`

    const [project] = await sql`SELECT ${sql.unsafe(projectColumns)} FROM bbs_projects WHERE id = ${projectId}`
    const [userMessage] = await sql`SELECT ${sql.unsafe(messageColumns)} FROM bbs_builder_messages WHERE id = ${userMessageId}`
    const [generatedMessage] = await sql`SELECT ${sql.unsafe(messageColumns)} FROM bbs_builder_messages WHERE id = ${generatedMessageId}`

    return { project, userMessage, generatedMessage }
  } catch (error) {
    await sql`UPDATE bbs_projects SET status = 'failed', updated_at = NOW() WHERE id = ${projectId}`
    throw error
  }
}

const addMessage = async (userId: string, { projectId, content }: { projectId: string; content: string }) => {
  const sql = getDb()
  const project = await getOwnedProject(userId, projectId)

  const [latestGenerated] = await sql`
    SELECT content FROM bbs_builder_messages
    WHERE project_id = ${projectId} AND role = 'assistant' AND status = 'complete'
    ORDER BY created_at DESC LIMIT 1
  `

  const userMessageId = randomBytes(16).toString('hex')
  const generatedMessageId = randomBytes(16).toString('hex')

  await sql`
    INSERT INTO bbs_builder_messages (id, project_id, user_id, role, content, status)
    VALUES (${userMessageId}, ${projectId}, ${userId}, 'user', ${content}, 'complete')
  `

  try {
    const html = await reviseWebsite({
      initialPrompt: project.initial_prompt as string,
      instruction: content,
      currentHtml: (latestGenerated?.content as string) || '',
    })

    await sql`
      INSERT INTO bbs_builder_messages (id, project_id, user_id, role, content, status)
      VALUES (${generatedMessageId}, ${projectId}, ${userId}, 'assistant', ${html}, 'complete')
    `
    await sql`UPDATE bbs_projects SET status = 'draft', updated_at = NOW() WHERE id = ${projectId}`

    const [userMessage] = await sql`SELECT ${sql.unsafe(messageColumns)} FROM bbs_builder_messages WHERE id = ${userMessageId}`
    const [generatedMessage] = await sql`SELECT ${sql.unsafe(messageColumns)} FROM bbs_builder_messages WHERE id = ${generatedMessageId}`

    return { userMessage, generatedMessage }
  } catch (error) {
    await sql`UPDATE bbs_builder_messages SET status = 'failed' WHERE id = ${userMessageId}`
    throw error
  }
}

const addDomain = async (userId: string, { hostname, projectId }: { hostname: string; projectId: string | null }) => {
  const sql = getDb()

  const cleanHostname = hostname.trim().toLowerCase().replace(/^https?:\/\//i, '').replace(/\/+$/, '')
  if (!cleanHostname) throw Object.assign(new Error('Enter a domain name.'), { status: 422 })

  let expectedTarget = ''
  if (projectId) {
    const project = await getOwnedProject(userId, projectId)
    if (project.published_url) {
      expectedTarget = new URL(project.published_url as string).hostname
    }
  }

  const dns = buildDnsInstructions(cleanHostname, expectedTarget || 'your-project.netlify.app')
  const id = randomBytes(16).toString('hex')

  await sql`
    INSERT INTO bbs_domains (id, user_id, project_id, hostname, status, record_type, expected_target)
    VALUES (${id}, ${userId}, ${projectId}, ${cleanHostname}, 'needs_configuration', ${dns.recordType}, ${dns.value})
  `

  const [domain] = await sql`SELECT ${sql.unsafe(domainColumns)} FROM bbs_domains WHERE id = ${id}`
  return { domain, dns }
}

const verifyDomain = async (userId: string, { domainId }: { domainId: string }) => {
  const sql = getDb()
  const [domain] = await sql`
    SELECT ${sql.unsafe(domainColumns)} FROM bbs_domains WHERE id = ${domainId} AND user_id = ${userId}
  `
  if (!domain) throw Object.assign(new Error('Domain not found.'), { status: 404 })

  const result = await checkDomain(domain.hostname as string, (domain.expected_target as string) || '')

  await sql`
    UPDATE bbs_domains SET status = ${result.status}, updated_at = NOW() WHERE id = ${domainId}
  `

  let attachMessage: string | null = null
  if (result.status === 'connected' && domain.project_id) {
    await sql`UPDATE bbs_projects SET custom_domain = ${domain.hostname} WHERE id = ${domain.project_id} AND user_id = ${userId}`

    const [project] = await sql`
      SELECT platform_site_id FROM bbs_projects WHERE id = ${domain.project_id} AND user_id = ${userId}
    `
    if (project?.platform_site_id) {
      try {
        const attachResult = await attachDomain({
          siteId: project.platform_site_id as string,
          hostname: domain.hostname as string,
        })
        attachMessage = attachResult.message
      } catch (error) {
        // DNS is confirmed even if Netlify hasn't accepted the attach yet
        // (e.g. propagation still settling on Netlify's side). Surface the
        // real error rather than silently swallowing it.
        attachMessage = (error as Error).message
      }
    } else {
      attachMessage = 'DNS is confirmed. Publish this project at least once before the domain can be attached to a live site.'
    }
  }

  const [updated] = await sql`SELECT ${sql.unsafe(domainColumns)} FROM bbs_domains WHERE id = ${domainId}`
  return { domain: updated, check: result, attachMessage }
}

const publish = async (userId: string, { projectId }: { projectId: string }) => {
  const sql = getDb()
  const project = await getOwnedProject(userId, projectId)

  const [latestGenerated] = await sql`
    SELECT content FROM bbs_builder_messages
    WHERE project_id = ${projectId} AND role = 'assistant' AND status = 'complete'
    ORDER BY created_at DESC LIMIT 1
  `
  if (!latestGenerated?.content) {
    throw Object.assign(new Error('Generate a website before publishing.'), { status: 422 })
  }

  const deploymentId = randomBytes(16).toString('hex')
  await sql`
    INSERT INTO bbs_deployments (id, user_id, project_id, project_name, status, is_latest)
    VALUES (${deploymentId}, ${userId}, ${projectId}, ${project.name}, 'building', TRUE)
  `
  await sql`UPDATE bbs_deployments SET is_latest = FALSE WHERE project_id = ${projectId} AND id != ${deploymentId}`

  try {
    const result = await publishProject({
      projectId,
      projectName: project.name as string,
      existingSiteId: (project.platform_site_id as string) || null,
      html: latestGenerated.content as string,
    })

    await sql`
      UPDATE bbs_deployments SET status = 'published', published_url = ${result.publishedUrl} WHERE id = ${deploymentId}
    `
    await sql`
      UPDATE bbs_projects
      SET status = 'published', published_url = ${result.publishedUrl}, platform_site_id = ${result.siteId}, updated_at = NOW()
      WHERE id = ${projectId}
    `

    const [project2] = await sql`SELECT ${sql.unsafe(projectColumns)} FROM bbs_projects WHERE id = ${projectId}`
    const [deployment] = await sql`SELECT ${sql.unsafe(deploymentColumns)} FROM bbs_deployments WHERE id = ${deploymentId}`
    return { project: project2, deployment }
  } catch (error) {
    await sql`UPDATE bbs_deployments SET status = 'failed' WHERE id = ${deploymentId}`
    throw error
  }
}

export const Route = createFileRoute('/api/builder-workspace')({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          await ensureTables()
          const user = await requireSessionUser(request)
          const workspace = await getWorkspace(user.id)
          return json(workspace)
        } catch (error) {
          return errorResponse(error)
        }
      },

      POST: async ({ request }) => {
        try {
          await ensureTables()
          const user = await requireSessionUser(request)
          const body = await request.json()
          const action = body.action as Action

          if (action === 'create-project') {
            const prompt = String(body.prompt || '').trim()
            const name = String(body.name || 'BBS Website').trim()
            if (prompt.length < 12) {
              return json({ error: 'Describe the website in at least 12 characters.' }, 422)
            }
            return json(await createProject(user.id, { prompt, name }))
          }

          if (action === 'add-message') {
            const projectId = String(body.projectId || '').trim()
            const content = String(body.content || '').trim()
            if (!projectId) return json({ error: 'Project ID is required.' }, 422)
            if (content.length < 2) return json({ error: 'Enter an instruction for the website.' }, 422)
            return json(await addMessage(user.id, { projectId, content }))
          }

          if (action === 'add-domain') {
            const hostname = String(body.hostname || '').trim()
            const projectId = body.projectId ? String(body.projectId) : null
            return json(await addDomain(user.id, { hostname, projectId }))
          }

          if (action === 'verify-domain') {
            const domainId = String(body.domainId || '').trim()
            if (!domainId) return json({ error: 'Domain ID is required.' }, 422)
            return json(await verifyDomain(user.id, { domainId }))
          }

          if (action === 'publish') {
            const projectId = String(body.projectId || '').trim()
            if (!projectId) return json({ error: 'Project ID is required.' }, 422)
            return json(await publish(user.id, { projectId }))
          }

          return json({ error: 'Unknown workspace action.' }, 400)
        } catch (error) {
          return errorResponse(error)
        }
      },
    },
  },
})
