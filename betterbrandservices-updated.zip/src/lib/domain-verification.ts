import { resolveCname, resolve4 } from 'node:dns/promises'

/**
 * Real DNS verification for custom domains. This performs actual DNS
 * lookups against public resolvers — it never fabricates a "connected"
 * status. A domain only becomes `connected` once its DNS records
 * genuinely point at the published site.
 */

export type DomainCheckResult = {
  status: 'connected' | 'pending' | 'needs_configuration'
  recordType: 'CNAME' | 'A'
  expectedTarget: string
  foundRecords: string[]
  message: string
}

const isApexDomain = (hostname: string) => hostname.split('.').length === 2

/**
 * Netlify (and most hosts) require a CNAME to the site's default subdomain
 * for non-apex hosts, and an A/ALIAS record for apex (root) domains because
 * DNS forbids a CNAME at the zone apex. We surface both cleanly.
 */
export const buildDnsInstructions = (hostname: string, targetSubdomain: string) => {
  if (isApexDomain(hostname)) {
    return {
      recordType: 'A' as const,
      name: '@',
      value: '75.2.60.5',
      note:
        'Apex/root domains cannot use a CNAME. Point an A (or your registrar\'s ALIAS/ANAME) record at this address, or add a CNAME on the "www" subdomain instead and redirect the root to it.',
    }
  }

  return {
    recordType: 'CNAME' as const,
    name: hostname.split('.')[0],
    value: targetSubdomain,
    note: 'Add a CNAME record pointing this subdomain at your published site address.',
  }
}

export async function checkDomain(
  hostname: string,
  expectedTarget: string,
): Promise<DomainCheckResult> {
  const apex = isApexDomain(hostname)

  try {
    if (apex) {
      const addresses = await resolve4(hostname)
      const connected = addresses.includes('75.2.60.5')
      return {
        status: connected ? 'connected' : 'pending',
        recordType: 'A',
        expectedTarget: '75.2.60.5',
        foundRecords: addresses,
        message: connected
          ? 'DNS is pointed correctly. HTTPS provisioning follows automatically once the host confirms ownership.'
          : 'DNS was resolved but does not yet point at the expected address.',
      }
    }

    const records = await resolveCname(hostname)
    const connected = records.some((record) =>
      record.toLowerCase().includes(expectedTarget.toLowerCase()),
    )
    return {
      status: connected ? 'connected' : 'pending',
      recordType: 'CNAME',
      expectedTarget,
      foundRecords: records,
      message: connected
        ? 'DNS is pointed correctly. HTTPS provisioning follows automatically once the host confirms ownership.'
        : 'A CNAME was found but does not point at the expected target yet.',
    }
  } catch {
    return {
      status: 'needs_configuration',
      recordType: apex ? 'A' : 'CNAME',
      expectedTarget: apex ? '75.2.60.5' : expectedTarget,
      foundRecords: [],
      message: 'No matching DNS record was found yet. Add the record shown below at your registrar.',
    }
  }
}
