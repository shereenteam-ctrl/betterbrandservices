import JSZip from 'jszip'

/**
 * Publishing backend. BBS already deploys its own marketing site on
 * Netlify (see netlify.toml), so builder projects publish through the
 * same Netlify account via its REST API — one real site per project,
 * created once and redeployed on every publish.
 *
 * Configure with:
 *   NETLIFY_AUTH_TOKEN   (required — a Netlify personal access token)
 *
 * Nothing here is simulated: if NETLIFY_AUTH_TOKEN is missing, publish
 * calls fail loudly with a clear configuration error instead of pretending
 * to succeed.
 */

const NETLIFY_API = 'https://api.netlify.com/api/v1'

export class PublishConfigError extends Error {}
export class PublishError extends Error {}

const getToken = () => {
  const token = process.env.NETLIFY_AUTH_TOKEN
  if (!token) {
    throw new PublishConfigError(
      'Publishing is not configured. Set NETLIFY_AUTH_TOKEN (a Netlify personal access token) to enable deployments.',
    )
  }
  return token
}

const netlifyFetch = async (path: string, init: RequestInit) => {
  const token = getToken()
  const response = await fetch(`${NETLIFY_API}${path}`, {
    ...init,
    headers: {
      ...(init.headers || {}),
      Authorization: `Bearer ${token}`,
    },
  })
  if (!response.ok) {
    const body = await response.text().catch(() => '')
    throw new PublishError(`Netlify API error (${response.status}): ${body.slice(0, 300)}`)
  }
  return response
}

const slugify = (value: string) =>
  value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40) || 'bbs-site'

/**
 * Creates a dedicated Netlify site for a project the first time it is
 * published. Reuses the same site (passed in as `existingSiteId`) on every
 * later publish so the URL stays stable.
 */
export async function ensureSite(params: {
  projectId: string
  projectName: string
  existingSiteId: string | null
}): Promise<{ siteId: string; url: string; sslUrl: string }> {
  if (params.existingSiteId) {
    const response = await netlifyFetch(`/sites/${params.existingSiteId}`, { method: 'GET' })
    const site = (await response.json()) as { id: string; url: string; ssl_url: string }
    return { siteId: site.id, url: site.url, sslUrl: site.ssl_url }
  }

  const name = `${slugify(params.projectName)}-${params.projectId.slice(0, 8)}`
  const response = await netlifyFetch('/sites', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ name }),
  })
  const site = (await response.json()) as { id: string; url: string; ssl_url: string }
  return { siteId: site.id, url: site.url, sslUrl: site.ssl_url }
}

/**
 * Deploys the generated HTML to the given Netlify site as a single-file
 * zip upload (Netlify's documented "deploy from zip" API), then waits
 * briefly for the deploy to leave the "processing" state.
 */
export async function deployHtml(params: {
  siteId: string
  html: string
}): Promise<{ deployId: string; publishedUrl: string; status: string }> {
  const zip = new JSZip()
  zip.file('index.html', params.html)
  const zipBuffer = await zip.generateAsync({ type: 'uint8array' })

  const response = await netlifyFetch(`/sites/${params.siteId}/deploys`, {
    method: 'POST',
    headers: { 'content-type': 'application/zip' },
    body: new Blob([zipBuffer as unknown as BlobPart]),
  })

  const deploy = (await response.json()) as {
    id: string
    state: string
    ssl_url?: string
    url?: string
  }

  return {
    deployId: deploy.id,
    publishedUrl: deploy.ssl_url || deploy.url || '',
    status: deploy.state,
  }
}

/**
 * Registers a custom domain as the site's primary domain via Netlify's API.
 * This is the step that makes Netlify actually route traffic for the domain
 * and provision an SSL certificate for it — DNS pointing correctly is a
 * prerequisite, not a substitute, for this call.
 */
export async function attachDomain(params: {
  siteId: string
  hostname: string
}): Promise<{ attached: boolean; message: string }> {
  const response = await fetch(`${NETLIFY_API}/sites/${params.siteId}`, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${getToken()}`,
      'content-type': 'application/json',
    },
    body: JSON.stringify({ custom_domain: params.hostname }),
  })

  if (!response.ok) {
    const body = await response.text().catch(() => '')
    throw new PublishError(
      `Netlify could not attach ${params.hostname} (${response.status}): ${body.slice(0, 300)}`,
    )
  }

  return {
    attached: true,
    message: 'Domain attached. SSL provisioning begins automatically once Netlify confirms DNS.',
  }
}

export async function publishProject(params: {
  projectId: string
  projectName: string
  existingSiteId: string | null
  html: string
}) {
  const site = await ensureSite({
    projectId: params.projectId,
    projectName: params.projectName,
    existingSiteId: params.existingSiteId,
  })
  const deploy = await deployHtml({ siteId: site.siteId, html: params.html })

  return {
    siteId: site.siteId,
    publishedUrl: deploy.publishedUrl || site.sslUrl || site.url,
    deployId: deploy.deployId,
    status: deploy.status,
    /** The subdomain used for CNAME-based custom domain instructions. */
    defaultDomain: new URL(site.sslUrl || site.url).hostname,
  }
}
